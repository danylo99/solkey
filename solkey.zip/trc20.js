const bip39 = require('bip39');
const hdkey = require('hdkey');
const { keccak256 } = require('js-sha3');
const { ec } = require('elliptic');
const bs58 = require('bs58');

// Generate a random 12-word seed phrase
const mnemonic = bip39.generateMnemonic(128); // 128 bits of entropy for a 12-word seed phrase
console.log('12-Word Seed Phrase:', mnemonic);

// Derive the seed from the mnemonic phrase
const seed = bip39.mnemonicToSeedSync(mnemonic);
const masterKey = hdkey.fromMasterSeed(seed);
const derivedKey = masterKey.derive("m/44'/195'/0'/0/0");

// Get the private key
const privateKey = derivedKey.privateKey.toString('hex');

// Create a TRC20 wallet address offline
const ecInstance = new ec('secp256k1');
const keyPair = ecInstance.keyFromPrivate(privateKey);
const pubKey = keyPair.getPublic(true, 'hex');
const address = keccak256(Buffer.from(pubKey, 'hex')).slice(-40);
const hexAddress = '41' + address;
const addressBuffer = Buffer.from(hexAddress, 'hex');
const checksum = Buffer.from(keccak256(addressBuffer).slice(0, 8), 'hex');
const base58Address = bs58.default.encode(Buffer.concat([addressBuffer, checksum]));

console.log('TRC20 Wallet Address:', base58Address);
console.log('Private Key:', privateKey);
