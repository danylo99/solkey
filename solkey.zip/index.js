const { Keypair } = require('@solana/web3.js');
const bip39 = require('bip39');
const { derivePath } = require('ed25519-hd-key');

// Generate a random 12-word seed phrase
const generateSeed = () => {
  const mnemonic = bip39.generateMnemonic(128); // 128 bits of entropy for a 12-word seed phrase
  console.log('12-Word Seed Phrase:', mnemonic);
  return mnemonic;
};

//Generate keypair from seed phrase
const generateKeypairFromSeed = (mnemonic) => {
  const seed = bip39.mnemonicToSeedSync(mnemonic).slice(0, 32);
  const derivedSeed = derivePath("m/44'/501'/0'/0'", seed.toString('hex')).key;
  const keypair = Keypair.fromSeed(derivedSeed);
  console.log('mnemonic:', mnemonic);
  console.log('Keypair Address:', keypair.publicKey.toBase58());
  console.log('Keypair Secret Key:', Buffer.from(keypair.secretKey).toString('hex'));
};

// Run the functions
const mnemonic = generateSeed();
console.log(mnemonic)
generateKeypairFromSeed(mnemonic);
